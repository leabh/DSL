/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.util.ArrayList;

/**
 *
 * @author Lea
 */
public class AnneeScolaire {

    private int id;
    private int anneedebut;
    private String periode;
 
    public AnneeScolaire()
    {}
    
    public AnneeScolaire(int m_id, int ad) {
        id = m_id;
        anneedebut = ad;
    }
    
    public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
    
    public int getAnneeDeb() 
    {
        return anneedebut;
    }

    public void setAnneeDeb(int anneedeb) 
    {
        this.anneedebut = anneedeb;
    }
    
    /**
     *Méthode calcul période
     * @param a
     * @return
     */
    public String Periode(int a) {
        int anneefin;
        anneefin = (a) + 1;
        periode = a + "-" + anneefin;
        return periode;
    }
    
     public String getPeriode() 
    {
        return periode;
    }

    public void setPeriode(String periode) 
    {
        this.periode = periode;
    }

}
