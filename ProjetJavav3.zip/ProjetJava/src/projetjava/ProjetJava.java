/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;
import DAO.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import DAO.*;
import java.util.Scanner;


/**
 *
 * @author Lea
 */
public class ProjetJava {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // TODO code application logic here
        Connexion c = new Connexion("projetjava","root", "");
  
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/projetjava","root", "");
           //Testons
           int choix=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Ajouter Niveau");
        System.out.println("2. Ajouter Classe");
        System.out.println("3. Supprimer eleve");
        System.out.println("4. Affiche eleves");
        System.out.println("5. Affiche profs");
        System.out.println("6. Recherche un eleve");
        
        choix = sc.nextInt();
        if(choix == 1)
        {
            Ajouter a = new Ajouter();
            a.AjoutNiveau();
        }
        else
            if(choix == 2)
            {
                System.out.println("coucou");
            }
        
        if(choix == 3)
            {
                Supprimer s = new Supprimer();
                s.SupprEleve(c);
            }
        if(choix == 4)
            {
                Recherche r = new Recherche();
                r.afficheEleves();
            }
        if(choix == 5)
            {
                Recherche r = new Recherche();
                r.afficheProfs();
            }
        if(choix == 6)
            {
                Recherche r = new Recherche();
                r.rechercheEleve(c);
            }
        
        
          /* DAO<Personne> eleveDao = new PersonneDAO(conn);
           DAO<Classe> clsDao = new ClasseDAO(conn);
           DAO<Inscription> insdao = new InscriptionDAO(conn);
           DAO<Bulletin> bulldao = new BulletinDAO(conn);
           
        for(int i = 1; i < 10; i++){
        Personne eleve = eleveDao.find(i);
        if("eleve".equals(eleve.getType()))
        {System.out.println("Id de l'élève : " + eleve.getId() + "  - " + eleve.getNom() + " " + eleve.getPrenom());
            
        System.out.println("choisissez un élève :");
        int a = sc.nextInt();
        Personne p = eleveDao.find(a);
        System.out.println("notes :");
        
        
        }
        }
    }
           
        //DAO<Classe> clsdao = new ClasseDAO(conn);
        //DAO<Personne> persdao = new PersonneDAO(conn);
        /*DAO<Classe> clsdao = new ClasseDAO(conn);
        DAO<Personne> persdao = new PersonneDAO(conn);
        Classe b = new Classe(50, "sasou");
        clsdao.create(b);*/
        
       /*Scanner sc = new Scanner(System.in);
       
        System.out.println("Id de la personne que vous recherchez : ");
        int j = sc.nextInt();
        
        //Recherche personne
        Personne p = persDao.find(j); 
        System.out.println("nom : " + p.getNom() + " prénom : " +p.getPrenom());
        
        if("eleve".equals(p.getType()))
        {
            System.out.println(p.getInscription().getId()+ " et " + p.getInscription().getClasse().getNom() +
                    " et " + p.getInscription().getClasse().getNiveau().getNom());
            System.out.println(p.getInscription().getClasse().getAnneeScolaire().getPeriode());
            
        
            System.out.println("Quel trimestre ? : ");
            int i = sc.nextInt();
            System.out.println(p.getInscription().getClasse().getAnneeScolaire().getListeT().get(i).getBulletin().getMoy());
            System.out.println(p.getInscription().getClasse().getAnneeScolaire().getListeT().get(i).getBulletin().getAppreciation());

}*/
    }
    
}
