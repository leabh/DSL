/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import DAO.DAO;
import DAO.DAOFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sandid
 */
public class Recherche {
    
        DAO<Personne> persDao = DAOFactory.getPersonneDAO();
        DAO<Classe> clsDao = DAOFactory.getClasseDAO();
        DAO<Inscription> insDao = DAOFactory.getInscriptionDAO();
        DAO<Bulletin> bullDao = DAOFactory.getBulletinDAO();
        DAO<DetailBulletin> dbDao = DAOFactory.getDetaiBulletinDAO();
        DAO<Niveau> nivDao = DAOFactory.getNiveauDAO();
        DAO<Evaluation> evalDao = DAOFactory.getEvaluationDAO();
        DAO<Enseignement> ensDao = DAOFactory.getEnseignementDAO();
        DAO<Discipline> disDao = DAOFactory.getDisciplineDAO();
        DAO<Trimestre> trimDao = DAOFactory.getTrimestreDAO();
        Scanner sc = new Scanner(System.in);
        
        public Recherche(){}
        
        
        public void afficheEleves()
        {
            for(int i = 0; i <50 ; i++){
            Personne eleve = persDao.find(i);
            if("eleve".equals(eleve.getType()))
        {System.out.println("Id de l'élève : " + eleve.getId() + "  - " + eleve.getNom() + " " + eleve.getPrenom());
            
        }
            }
  
        }
        
        public void afficheProfs()
        {
            for(int i = 0; i <50 ; i++){
            Personne prof = persDao.find(i);
            if("prof".equals(prof.getType()))
        {System.out.println("Id du prof : " + prof.getId() + "  - " + prof.getNom() + " " + prof.getPrenom());
            
        }
            }
         }
        
        public void rechercheEleve(Connexion c) throws SQLException
        {
            int idE;
            afficheEleves();
            System.out.println("Choisissez l'id d'un étudiant : ");
            idE = sc.nextInt(); 
            Personne p;
            int insIdre;
            ArrayList<String> bIdre = new ArrayList<>();
            ArrayList<String> dbIdre = new ArrayList<>();
            ArrayList<String> evalIdre = new ArrayList<>();
            
            
            p = persDao.find(idE);
            
            ArrayList<String> liste = new ArrayList<>();
            ArrayList<String> liste2 = new ArrayList<>();
               
            liste = c.remplirChampsRequete("SELECT id FROM inscription WHERE idPersonne = "+p.getId()+"");
            
            Scanner scan = new Scanner(liste.get(0));
            insIdre = scan.nextInt();
            
            Inscription i = new Inscription();
            
            i = insDao.find(insIdre);
            
            System.out.println("Classe : "+i.getClasse().getNom() + " " + i.getClasse().getNiveau().getNom() + " "+
                    i.getClasse().getAnneeScolaire().getPeriode());
                      
            liste2 = c.remplirChampsRequete("SELECT id FROM bulletin WHERE idInscription = "+insIdre+"");

            //System.out.println(insIdre);
                        
            for(int j=0; j<liste2.size(); j++)
            {
                bIdre.add(liste2.get(j));   
            }
            
            for(int j=0; j<bIdre.size(); j++)
            {
                System.out.println(bIdre);
                
                liste2 = c.remplirChampsRequete("SELECT id FROM detailbulletin WHERE idBulletin = "+bIdre.get(j)+"");
                
                for(int k=0; k<liste.size(); k++)
                {
                    dbIdre.add(liste2.get(k));
                   
                }
                
            }
            
                for(int j=0; j < dbIdre.size(); j++)
            {
                liste2 = c.remplirChampsRequete("SELECT id FROM evaluation WHERE idDetailBulletin = "+dbIdre.get(j)+"");
                
                for(int k=0; k<liste2.size(); k++)
                {
                    evalIdre.add(liste2.get(k));
                    
                }
                //System.out.println(evalIdsup);
            }
                
                //Recherche
                for(int j=0; j<evalIdre.size(); j++)
                {
                    scan = new Scanner(evalIdre.get(j));
                    int a = scan.nextInt();
                    
                    Evaluation eval = evalDao.find(a);
                    System.out.println(eval.getNote()+" - "+ eval.getAppreciation());
                }
                for(int j=0; j<dbIdre.size(); j++)
                {
                    scan = new Scanner(evalIdre.get(j));
                    int a = scan.nextInt();
                    DetailBulletin db = dbDao.find(a);
                    System.out.println("Enseignement : " + db.getEnseignement().getDiscipline() 
                            + " Moyenne : " + db.getMoy() + " Appréciation : " + db.getAppreciation());
                }
                
                for(int j=0; j<bIdre.size(); j++)
                {   
                    scan = new Scanner(evalIdre.get(j));
                    int a = scan.nextInt();
                    Bulletin b = bullDao.find(a);
                }
               
        }
     
}
