/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

/**
 *
 * @author Lea
 */
public class Classe {
    
  private int id;
          //idA, idN;
  private String nom;
  private AnneeScolaire annee;
  private Niveau niv;
  
  //cle secondaire :  Niveau.id, AnnéeScolaire.id
  
  public Classe(int m_id, String m_nom)
  {
    //this.idA = idA;
    //this.idN = idN;
    id=m_id;
    nom = m_nom;
  }

    public Classe() {}
    
  
  public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
  
     public String getNom() 
    {
        return nom;
    }

    public void setNom(String m_nom) 
    {
        nom = m_nom;
    }
    public AnneeScolaire getAnneeScolaire() 
    {
        return annee;
    }

    public void setAnneeScolaire(AnneeScolaire m_A) 
    {
        annee = m_A;
    }
    public Niveau getNiveau() 
    {
        return niv;
    }

    public void setNiveau(Niveau m_N) 
    {
        niv = m_N;
    }
    
}
