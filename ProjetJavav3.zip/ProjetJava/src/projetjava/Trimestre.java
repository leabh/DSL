/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

/**
 *
 * @author Lea
 */
public class Trimestre {

    private int id;
    private String debut;
    private String fin;
    private int numero;
    private AnneeScolaire annee;

    
    public Trimestre(int id, int numero, String m_debut, String m_fin) {
        this.id = id;
        this.numero = numero;
        debut = m_debut;
        fin = m_fin; 
    }

    public Trimestre() {}
    
    public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
    
    public int getNum() 
    {
        return numero;
    }

    public void setNum(int numero) 
    {
        this.numero = numero;
    }

    public String getDebut() 
    {
        return debut;
    }

    public void setDebut(String debut) 
    {
        this.debut = debut;
    }
    
    public String getFin() 
    {
        return fin;
    }

    public void setFin(String fin) 
    {
        this.fin = fin;
    }
    
    public AnneeScolaire getAnnee() 
    {
        return annee;
    }

    public void setAnneeScolaire(AnneeScolaire A) 
    {
        annee = A;
    }
        
}
