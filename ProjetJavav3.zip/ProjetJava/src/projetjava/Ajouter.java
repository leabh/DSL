/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;


import DAO.DAO;
import DAO.DAOFactory;
import java.util.Scanner;

/**
 *
 * @author Sandid
 */
public class Ajouter {
          
        DAO<Personne> persDao = DAOFactory.getPersonneDAO();
        DAO<Classe> clsDao = DAOFactory.getClasseDAO();
        DAO<Inscription> insDao = DAOFactory.getInscriptionDAO();
        DAO<Bulletin> bullDao = DAOFactory.getBulletinDAO();
        DAO<DetailBulletin> dbDao = DAOFactory.getDetaiBulletinDAO();
        DAO<Niveau> nivDao = DAOFactory.getNiveauDAO();
        DAO<Evaluation> evalDao = DAOFactory.getEvaluationDAO();
        DAO<Enseignement> ensDao = DAOFactory.getEnseignementDAO();
        DAO<Discipline> disDao = DAOFactory.getDisciplineDAO();
        DAO<Trimestre> trimDao = DAOFactory.getTrimestreDAO();
        Scanner sc = new Scanner(System.in);
        
        Ajouter(){}

        
    public void AjoutNiveau()
    {
        System.out.println("Quel niveau ajouter ? ");
        
        int cond =1;
        String ajout = sc.nextLine();
        Niveau n = new Niveau();

        for(int i = 1; i<20 ; i++)
        {
           n = nivDao.find(i);
           
           if(ajout.equals(n.getNom()))
           {
               cond = 0; 
               System.out.println("Déjà la");
           }              

        }
        if(cond == 1)
                {
                    try{
                        n.setNom(ajout);
                        nivDao.create(n);
                        System.out.print("Ajout !");
                    }
                    catch(Exception e)
                    {
                        System.out.print("Pas d'ajout");
                    }  
                }     
    }
    
  
    public void AjouterClasse()
    {
        Niveau n;
        int cond=0;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Nom de la classe ? ");
        String nomC = sc.nextLine();
        System.out.println("Niveau ?");
        String niveau = sc.nextLine();
        System.out.println("Annee ? ");
        int annee = sc.nextInt();
        
        //if(niveau == )
        
        
        
        
        
   
        
        
    }
    
    public void AjouterEleve()
      {
          System.out.println("Nom ? ");
          String nom = sc.next();
          System.out.println("Prenom? ");
          String prenom = sc.next();
          System.out.println("eleve ou prof ? ");
          String type = sc.next();
          
      }
}
