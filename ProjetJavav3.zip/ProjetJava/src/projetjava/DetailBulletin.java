/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.util.ArrayList;

/**
 *
 * @author Lea
 */
public class DetailBulletin {

    private int id, idB;
    private String appreciation;
    private ArrayList<Evaluation> evaluations = new ArrayList<>();
    private float moy;
    Enseignement E;
//clé secondaire :  Bulletin.id, Enseignement.id
    
    public DetailBulletin(int id, String m_appreciation, int idB) {

        this.id = id;
        appreciation = m_appreciation;
        this.idB = idB;
    }
    
    public DetailBulletin(){}
    
    
     public ArrayList<Evaluation> getEval() 
    {
        return evaluations;
    }

    public void setEval(ArrayList<Evaluation> m_evaluations) 
    {
       evaluations =  m_evaluations;
    }
    
    public void AddEval(Evaluation e) 
    {
       evaluations.add(e);
    }
    
     public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
    
    public int getIdB() 
    {
        return idB;
    }

    /**
     *
     * @param idB
     */
    public void setIdB(int idB) 
    {
        this.idB = idB;
    }
   
     public String getAppreciation() 
    {
        return appreciation;
    }

    public void setAppreciation(String appreciation) 
    {
        this.appreciation = appreciation;
    }
    
   public Enseignement getEnseignement() 
    {
        return E;
    }

    public void setEnseignement(Enseignement e) 
    {
        this.E = e;
    }
    
    public float moyenne(ArrayList<Evaluation> e)
    {
        double somme = 0;
        for (int i=0; i<e.size(); i++)
        {  
            somme += e.get(i).getNote();
        }
        
        moy = (float) somme/e.size();
        return moy;
    }
    
    public float getMoy() 
    {
        return moy;
    }

    public void setMoy(float moy) 
    {
        this.moy = moy;
    }
    
}
