/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import DAO.DAO;
import DAO.DAOFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sandid
 */
public class Supprimer {
    
        DAO<Personne> persDao = DAOFactory.getPersonneDAO();
        DAO<Classe> clsDao = DAOFactory.getClasseDAO();
        DAO<Inscription> insDao = DAOFactory.getInscriptionDAO();
        DAO<Bulletin> bDao = DAOFactory.getBulletinDAO();
        DAO<DetailBulletin> dbDao = DAOFactory.getDetaiBulletinDAO();
        DAO<Niveau> nivDao = DAOFactory.getNiveauDAO();
        DAO<Evaluation> evalDao = DAOFactory.getEvaluationDAO();
        DAO<Enseignement> ensDao = DAOFactory.getEnseignementDAO();
        DAO<Discipline> disDao = DAOFactory.getDisciplineDAO();
        DAO<Trimestre> trimDao = DAOFactory.getTrimestreDAO();
        Scanner sc = new Scanner(System.in);
        
       public Supprimer(){}

    /**
     *Methode de suppression d'un etudiant
     * @param c
     * @throws java.sql.SQLException
     */
    public void SupprEleve(Connexion c) throws SQLException
       {
           String nom;
           int temp = 0;
           int id_elv = 0;
           int persIdsup;
           int insIdsup;
           //Arraylist de bulletins à supprimer
           ArrayList<String> bIdsup = new ArrayList<>();
           //Arraylist de details bulletins à supprimer
           ArrayList<String> dbIdsup = new ArrayList<>();
           //Arraylist de evaluations à supprimer
           ArrayList<String> evalIdsup = new ArrayList<>();
           
           
           System.out.println("Nom de famille de l'étudiant : ");
           nom = sc.nextLine();
           
           for(int i=1; i<100; i++)
           {
               Personne p = persDao.find(i);
               
               if(nom.equals(p.getNom()))
               {
                   if("eleve".equals(p.getType()))
                   {
                       temp = 1;
                       id_elv = p.getId();
                   }
               }
           }
           
           if(temp == 1)
           {
               System.out.println("Eleve à supprimer : " + persDao.find(id_elv).getNom()
                       + " " + persDao.find(id_elv).getPrenom());
               persIdsup = persDao.find(id_elv).getId();
               
            ArrayList<String> liste = new ArrayList<>();
               
            liste = c.remplirChampsRequete("SELECT id FROM inscription WHERE idPersonne = "+persIdsup+"");
            
            Scanner scan = new Scanner(liste.get(0));
            insIdsup = scan.nextInt();
            //System.out.println(insIdsup);
            
            liste = c.remplirChampsRequete("SELECT id FROM bulletin WHERE idInscription = "+insIdsup+"");
            
            for(int i=0; i<liste.size(); i++)
            {
                bIdsup.add(liste.get(i));
                 
            }
            for(int i=0; i<bIdsup.size(); i++)
            //{System.out.println(bIdsup);
            liste = c.remplirChampsRequete("SELECT id FROM detailbulletin WHERE idBulletin = "+bIdsup.get(i)+"");
                
                for(int j=0; j<liste.size(); j++)
                {
                    dbIdsup.add(liste.get(j));
                   
                }
                
                for(int i=0; i<dbIdsup.size(); i++)
            {
                liste = c.remplirChampsRequete("SELECT id FROM evaluation WHERE idDetailBulletin = "+dbIdsup.get(i)+"");
                
                for(int j=0; j<liste.size(); j++)
                {
                    evalIdsup.add(liste.get(j));
                    
                }
                //System.out.println(evalIdsup);
            }
                
                //Suppression
                for(int i=0; i<evalIdsup.size(); i++)
                {
                    scan = new Scanner(evalIdsup.get(i));
                    int a = scan.nextInt();
                    
                    evalDao.delete(a);
                }
                for(int i=0; i<dbIdsup.size(); i++)
                {
                    scan = new Scanner(evalIdsup.get(i));
                    int a = scan.nextInt();
                    dbDao.delete(a);
                }
                for(int i=0; i<bIdsup.size(); i++)
                {   
                    scan = new Scanner(evalIdsup.get(i));
                    int a = scan.nextInt();
                    bDao.delete(a);
                }
                insDao.delete(insIdsup);
                persDao.delete(persIdsup);
                
            }
           else if(temp == 0){
               System.out.println("Pas de match");
           }

           }

    
    public void SupprNote()
    {
        
    }
    
    public void SupprEnseignement()
    {
        
    }
}
