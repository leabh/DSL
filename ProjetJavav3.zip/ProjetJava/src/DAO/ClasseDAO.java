/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.Classe;
import projetjava.Inscription;

/**
 *
 * @author Sandid
 */
public class ClasseDAO extends DAO<Classe>{
    
    public ClasseDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Classe obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO classe (nom, idNiveau, idAnneeScolaire) VALUES (?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getNom(), Types.VARCHAR);
        statement.setObject(2, obj.getNiveau().getId(), Types.INTEGER);
        statement.setObject(3, obj.getAnneeScolaire().getId(), Types.INTEGER);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(ClasseDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
         
    }

    @Override
    public boolean delete(int id) {
         try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM classe WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(ClasseDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }

    @Override
    public boolean update(Classe obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Classe find(int id) {
        
        Classe cls = new Classe();
       
      try{ 
    
        ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM classe WHERE id = " +id);
        
        if(result.first())
        {
            cls = new Classe(id, result.getString("nom"));
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM classe " +
            "INNER JOIN niveau ON niveau.id = classe.idNiveau WHERE classe.id = " +id);
            
            NiveauDAO nivDao = new NiveauDAO(this.connect);
            
            while(result.next())
            {
                cls.setNiveau(nivDao.find(result.getInt("niveau.id")));                
            }
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM classe " +
            "INNER JOIN anneescolaire ON anneescolaire.id = classe.idAnneeScolaire WHERE classe.id = " +id);
            
            AnneeScolaireDAO asDao = new AnneeScolaireDAO(this.connect);
            
            while(result.next())
            {
                cls.setAnneeScolaire(asDao.find(result.getInt("anneescolaire.id")));
            }
        
        }
      
}
      catch (SQLException e) {e.getMessage();}
      
        return cls;
      
}
    
}
