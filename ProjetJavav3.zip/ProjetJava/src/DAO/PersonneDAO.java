/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.AnneeScolaire;
import projetjava.Personne;

/**
 *
 * @author Sandid
 */
public class PersonneDAO extends DAO<Personne>{
    
    public PersonneDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Personne obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO personne(nom, prenom, type) VALUES (?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getNom(), Types.VARCHAR);
        statement.setObject(2, obj.getPrenom(), Types.VARCHAR);
        statement.setObject(3, obj.getType(), Types.VARCHAR);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(PersonneDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
    }

    @Override
    public boolean delete(int id) {
       try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM personne WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(PersonneDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }

    @Override
    public boolean update(Personne obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Personne find(int id) {
        
      Personne pers = new Personne();
       
      try{ 
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM personne WHERE id = " +id);

      if(result.first())
      {
         pers = new Personne(id, result.getString("nom"), result.getString("prenom"), result.getString("type"));
         
         /*if("eleve".equals(result.getString("type")))
         {
             result = this.connect.createStatement().executeQuery(
            "SELECT * FROM personne " +
            "INNER JOIN inscription ON personne.id = inscription.idPersonne WHERE personne.id = " +id);
             
            InscriptionDAO insDao = new InscriptionDAO(this.connect);
            
            while(result.next())
          {
              pers.setInscription(insDao.find(result.getInt("inscription.id")));
                 
          }
  
         }
         
         else if("prof".equals(result.getString("type")))
         {
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM personne " +
            "INNER JOIN enseignement ON personne.id = enseignement.idPersonne WHERE personne.id = " +id);
            
            EnseignementDAO ensDao = new EnseignementDAO(this.connect);
            
            while(result.next())
            {
                pers.AddEnseignement(ensDao.find(result.getInt("enseignement.id")));
            }
            
         }*/

      }
     }
      catch (SQLException e) {
      e.getMessage();
    }
        
        return pers;
    }
   
}
