/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.AnneeScolaire;
import projetjava.Trimestre;

/**
 *
 * @author Sandid
 */
public class AnneeScolaireDAO extends DAO<AnneeScolaire> {
       
    public AnneeScolaireDAO(Connection conn)
    {
        super(conn);
    }
   
  /**
  * Méthode de création
  * @param obj
  * @return boolean 
  */
    @Override
  public boolean create(AnneeScolaire obj)
  {
      try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO anneescolaire (anneedebut) VALUE (?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getAnneeDeb(), Types.INTEGER);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(AnneeScolaireDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;

  }

  /**
  * Méthode pour effacer
  * @return boolean 
  */

    @Override
  public boolean delete(int id)
  {
      try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM anneescolaire WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(AnneeScolaireDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
  }

  /**
  * Méthode de mise à jour
  * @param obj
  * @return boolean
  */
    @Override
  public boolean update(AnneeScolaire obj)
  {
      return false;
  }

  /**
  * Méthode de recherche des informations
  * @param id
  * @return T
  */
    @Override
  public AnneeScolaire find(int id)
  {
      AnneeScolaire a = new AnneeScolaire();
      
      try{ 
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM anneescolaire WHERE id = " +id);

       if(result.first())
      {
          String p = a.Periode(result.getInt("anneedebut"));
          
          a = new AnneeScolaire(id, result.getInt("anneedebut"));
          a.setPeriode(p);
          
      }

    } catch (SQLException e) {
      e.getMessage();
    }
    return a;
  }

}
