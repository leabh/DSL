/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.DetailBulletin;
import projetjava.Enseignement;

/**
 *
 * @author Sandid
 */
public class EnseignementDAO extends DAO<Enseignement>{
    
    public EnseignementDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Enseignement obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO enseignement (idClasse, idDiscipline, idPersonne) VALUES (?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getClasse().getId(), Types.INTEGER);
        statement.setObject(2, obj.getDiscipline().getId(), Types.INTEGER);
        statement.setObject(3, obj.getPersonne().getId(), Types.INTEGER);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(AnneeScolaireDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;

    }

    @Override
    public boolean delete(int id) {
        try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM enseignement WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(AnneeScolaireDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }
    

    @Override
    public boolean update(Enseignement obj) {
        return false;
    }

    @Override
    public Enseignement find(int id) {
        
        Enseignement ens = new Enseignement();
      
      try{ 
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM enseignement WHERE id = " +id);

       if(result.first())
       {
           ens = new Enseignement(id);
           
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM enseignement " +
            "INNER JOIN classe ON classe.id = enseignement.idClasse WHERE enseignement.id = " +id);
           
            ClasseDAO clsDao = new ClasseDAO(this.connect);
            
            while(result.next())
            {
                ens.setClasse(clsDao.find(result.getInt("classe.id")));
            }
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM enseignement " +
            "INNER JOIN discipline ON discipline.id = enseignement.idDiscipline WHERE enseignement.id = " +id);
            
            DisciplineDAO disDao = new DisciplineDAO(this.connect);
            
            while(result.next())
            {
                ens.setDiscipline(disDao.find(result.getInt("discipline.id")));
            } 
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM enseignement " +
            "INNER JOIN personne ON personne.id = enseignement.idPersonne WHERE enseignement.id = " +id);
            
            PersonneDAO persDao = new PersonneDAO(this.connect);
            
            while(result.next())
            {
                if("prof".equals(result.getString("personne.type")))
                {
                ens.setPersonne(persDao.find(result.getInt("personne.id")));
                }
            }
       }
        
    }
      catch (SQLException e) {e.getMessage(); }
      
      return ens;   
}
    
}
