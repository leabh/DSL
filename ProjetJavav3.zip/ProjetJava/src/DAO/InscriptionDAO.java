/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.Inscription;

/**
 *
 * @author Sandid
 */
public class InscriptionDAO extends DAO<Inscription> {
    
    public InscriptionDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Inscription obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO inscription (idClasse, idPersonne) VALUES (?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getClasse().getId(), Types.INTEGER);
        statement.setObject(2, obj.getPersonne().getId(), Types.INTEGER);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(InscriptionDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
    }

    @Override
    public boolean delete(int id) {
         try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM inscription WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(InscriptionDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }

    @Override
    public boolean update(Inscription obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Inscription find(int id) {
        
        Inscription ins = new Inscription();
       
      try{ 
    
        ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM inscription WHERE id = " +id);
        
        if(result.first())
        {
            ins = new Inscription(id);
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM inscription " +
            "INNER JOIN classe ON classe.id = inscription.idClasse WHERE inscription.id = " +id);
            
            ClasseDAO clsDao = new ClasseDAO(this.connect);
            
            while(result.next())
          {
              ins.setClasse(clsDao.find(result.getInt("classe.id")));
          }
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM inscription " +
            "INNER JOIN personne ON personne.id = inscription.idPersonne WHERE inscription.id = " +id +
                    "AND personne.type = 'eleve'");
            
            PersonneDAO persDao = new PersonneDAO(this.connect);
            
            while(result.next())
          {
              ins.setPersonne(persDao.find(result.getInt("personne.id")));
          }
            
            result = this.connect.createStatement().executeQuery(
            "SELECT * FROM inscription " +
            "INNER JOIN bulletin ON inscription.id = bulletin.idInscription WHERE inscription.id = " +id);
            
            BulletinDAO bullDao = new BulletinDAO(this.connect);
            
            while(result.next())
            {
                ins.addBulletin(bullDao.find(result.getInt("bulletin.id")));
            }
 
        }

        }
      catch (SQLException e) {
      e.getMessage();
    }
      
      return ins;
    
    }
       
}
