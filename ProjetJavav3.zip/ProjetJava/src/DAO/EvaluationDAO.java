/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.DetailBulletin;
import projetjava.Evaluation;

/**
 *
 * @author Sandid
 */
public class EvaluationDAO extends DAO<Evaluation> {
    
    public EvaluationDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Evaluation obj) {
        
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO anneescolaire (idDetailBulletin, note, appreciation) VALUES (?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getIdDetailBulletin(), Types.INTEGER);
        statement.setObject(2, obj.getNote(), Types.DOUBLE);
        statement.setObject(3, obj.getAppreciation(), Types.VARCHAR);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(EvaluationDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
    }

    @Override
    public boolean delete(int id) {
       try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM evaluation WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(EvaluationDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }
    

    @Override
    public boolean update(Evaluation obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Evaluation find(int id) {
       
        
         Evaluation eval = new Evaluation();
      
      try{ 
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM evaluation WHERE id = " +id);
    
       if(result.first())
       {
            eval = new Evaluation(id, result.getDouble("note"), result.getString("appreciation"), result.getInt("detailbulletin.id"));
            //System.out.println(result.getDouble("note") + " et "+ result.getString("appreciation"));
       }
    }
      catch (SQLException e) {e.getMessage(); }

      return eval;
  }
    
}
