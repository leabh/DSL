/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.Discipline;
import projetjava.Enseignement;

/**
 *
 * @author Sandid
 */
public class DisciplineDAO extends DAO<Discipline> {
    
    public DisciplineDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Discipline obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO discipline (nom) VALUES (?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getNom(), Types.VARCHAR);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(AnneeScolaireDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
    }

    @Override
    public boolean delete(int id) {
        try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM discipline WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(DisciplineDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }

    @Override
    public boolean update(Discipline obj) {
         throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Discipline find(int id) {
        
        Discipline d = new Discipline();
      
      try{ 
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM discipline WHERE id = " +id);

       if(result.first())
       {
           d = new Discipline(id, result.getString("nom"));
       }
    }
      catch (SQLException e) {e.getMessage(); }
      
      return d;   
    
 }
    
}  
