/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.AnneeScolaire;
import projetjava.Trimestre;

/**
 *
 * @author Sandid
 */
public class TrimestreDAO extends DAO<Trimestre> {

     public TrimestreDAO(Connection conn)
    {
        super(conn);
    }
    
    @Override
    public boolean create(Trimestre obj) {
         try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO trimestre (numero,debut,fin,idAnneeScolaire) VALUES (?,?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getNum(), Types.INTEGER);
        statement.setObject(2, obj.getDebut(), Types.INTEGER);
        statement.setObject(3, obj.getFin(), Types.INTEGER);
        statement.setObject(4, obj.getAnnee().getId(), Types.INTEGER);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(TrimestreDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
    }

    @Override
    public boolean delete(int id) {
         try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM trimestre WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(TrimestreDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }

    @Override
    public boolean update(Trimestre obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Trimestre find(int id) {
        
      Trimestre trim = new Trimestre();
      
      try{
          
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM trimestre WHERE id = " +id);
      
      if(result.first())
      {
          
          trim = new Trimestre(id, result.getInt("numero"), result.getString("debut"), result.getString("fin"));
         
          result = this.connect.createStatement().executeQuery(
            "SELECT * FROM trimestre " +
            "INNER JOIN anneescolaire ON anneescolaire.id = trimestre.idAnneeScolaire WHERE trimestre.id = " +id);
        
        AnneeScolaireDAO anDao = new AnneeScolaireDAO(this.connect);
        
        while(result.next())
        {
           //System.out.println("hy"); 
          trim.setAnneeScolaire(anDao.find(result.getInt("anneescolaire.id"))); 
          
        }       
          
      }

    } catch (SQLException e) {
      e.getMessage();
    }
    return trim;
  }
    
}
