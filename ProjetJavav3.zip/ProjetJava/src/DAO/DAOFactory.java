/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import projetjava.Connexion;

/**
 *
 * @author Sandid
 */
public class DAOFactory {

  protected static final Connection conn = Connexion.getConn();   
   
  /**
  * Retourne un objet Classe interagissant avec la BDD
  * @return DAO
  */
  public static DAO getClasseDAO(){
    return new ClasseDAO(conn);
  }

  /**
  * Retourne un objet Personne interagissant avec la BDD
  * @return DAO
  */
  public static DAO getPersonneDAO(){
    return new PersonneDAO(conn);
  }

  /**
  * Retourne un objet AnneeScolaire interagissant avec la BDD
  * @return DAO
  */
  public static DAO getAnneeScolaireDAO(){
    return new AnneeScolaireDAO(conn);
  }

  /**
  * Retourne un objet Bulletin interagissant avec la BDD
  * @return DAO
  */
  public static DAO getBulletinDAO(){
    return new BulletinDAO(conn);
  } 

  /**
  * Retourne un objet DetailBulletin interagissant avec la BDD
  * @return DAO
  */
  public static DAO getDetaiBulletinDAO(){
    return new DetailBulletinDAO(conn);
  } 
  
  /**
  * Retourne un objet Discipline interagissant avec la BDD
  * @return DAO
  */
  public static DAO getDisciplineDAO(){
    return new DisciplineDAO(conn);
  } 
  
  /**
  * Retourne un objet Enseignement interagissant avec la BDD
  * @return DAO
  */
  public static DAO getEnseignementDAO(){
    return new EnseignementDAO(conn);
  } 
  
  /**
  * Retourne un objet Evaluation interagissant avec la BDD
  * @return DAO
  */
  public static DAO getEvaluationDAO(){
    return new EvaluationDAO(conn);
  } 
  
  /**
  * Retourne un objet Inscription interagissant avec la BDD
  * @return DAO
  */
  public static DAO getInscriptionDAO(){
    return new InscriptionDAO(conn);
  } 
  
  /**
  * Retourne un objet Niveau interagissant avec la BDD
  * @return DAO
  */
  public static DAO getNiveauDAO(){
    return new NiveauDAO(conn);
  }
  
  /**
  * Retourne un objet Trimestre interagissant avec la BDD
  * @return DAO
  */
  public static DAO getTrimestreDAO(){
    return new TrimestreDAO(conn);
  }
  
}

