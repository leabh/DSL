/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.Bulletin;
import projetjava.Inscription;

/**
 *
 * @author Sandid
 */
public class BulletinDAO extends DAO<Bulletin>{

     public BulletinDAO(Connection conn)
    {
        super(conn);
    }
    
    @Override
    public boolean create(Bulletin obj) {
         try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO bulletin (idTrimestre, idInscription, appreciation) VALUES (?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getTrimestre().getId(), Types.INTEGER);
        //a revoir
        statement.setObject(2, obj.getIdI(), Types.INTEGER);
        statement.setObject(3, obj.getAppreciation(), Types.VARCHAR);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(BulletinDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
         
    }

    @Override
    public boolean update(Bulletin obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Bulletin find(int id) {
        
         Bulletin b = new Bulletin();
       
      try{ 
    
        ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM bulletin WHERE id = " +id);
        
        if(result.first())
        {
            b = new Bulletin(id, result.getString("appreciation"), result.getInt("idInscription"));

        result = this.connect.createStatement().executeQuery(
            "SELECT * FROM bulletin " +
            "INNER JOIN detailbulletin ON bulletin.id = detailbulletin.idBulletin WHERE bulletin.id = " +id);
        
        DetailBulletinDAO dbDao = new DetailBulletinDAO(this.connect);
        
        while(result.next())
        { 
            b.AddDetailBulletin(dbDao.find(result.getInt("detailbulletin.id")));
            
        }
        
        result = this.connect.createStatement().executeQuery(
            "SELECT * FROM bulletin " +
            "INNER JOIN trimestre ON bulletin.idTrimestre = trimestre.id WHERE bulletin.id = " +id);
        
        TrimestreDAO trimDao = new TrimestreDAO(this.connect);
        
        while(result.next())
        {
            b.setTrimestre(trimDao.find(result.getInt("trimestre.id")));
        }
        
        float moy = b.moyenne(b.getDetailBulletin());
        b.setMoy(moy);
        
    }
      }
        catch (SQLException e) {e.getMessage(); }

      return b;
  }

    @Override
    public boolean delete(int id) {
        try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM bulletin WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(BulletinDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }
    
}
