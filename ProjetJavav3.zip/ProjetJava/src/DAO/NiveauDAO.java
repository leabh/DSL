/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.Classe;
import projetjava.Niveau;

/**
 *
 * @author Sandid
 */
public class NiveauDAO extends DAO<Niveau> {
    
    
    public NiveauDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(Niveau obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO niveau (nom) VALUE (?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getNom(), Types.VARCHAR);
        
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(NiveauDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
    }

    @Override
    public boolean delete(int id) {
         try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM niveau WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(NiveauDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
    }

    @Override
    public boolean update(Niveau obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Niveau find(int id) {
        
      Niveau niv = new Niveau();
       
      try{ 
    
        ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM niveau WHERE id = " +id);
        
        if(result.first())
        {
            niv = new Niveau(id, result.getString("nom"));
        }
        
        }
       catch (SQLException e) {e.getMessage();}
      
      return niv;
    }
    
}
