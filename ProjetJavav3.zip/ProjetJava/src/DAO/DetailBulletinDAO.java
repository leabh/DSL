/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import projetjava.DetailBulletin;

/**
 *
 * @author Sandid
 */
public class DetailBulletinDAO extends DAO<DetailBulletin>{
    
    public DetailBulletinDAO(Connection conn)
    {
        super(conn);
    }

    @Override
    public boolean create(DetailBulletin obj) {
        try {
             PreparedStatement statement = this.connect.prepareStatement(
                     "INSERT INTO detailbulletin (idBulletin, idEnseignement, appreciation) VALUES (?,?,?)");
        //statement.setObject(1, obj.getId(), Types.INTEGER);
        statement.setObject(1, obj.getIdB(), Types.INTEGER);
        statement.setObject(2, obj.getEnseignement().getId(), Types.INTEGER);
        statement.setObject(3, obj.getAppreciation(), Types.VARCHAR);
        statement.executeUpdate();   
             
         } catch (SQLException ex) {
             Logger.getLogger(BulletinDAO.class.getName()).log(Level.SEVERE, null, ex);
             return false;
         }
         return true;
        
         //To change body of generated methods, choose Tools | Templates.
    }

  @Override  
    public boolean delete(int id) {
        
         try{
          PreparedStatement stmt = this.connect.prepareStatement("DELETE FROM detailbulletin WHERE id = (?)");
          stmt.setObject(1, id, Types.INTEGER);
          stmt.executeUpdate();
      }
      catch(SQLException ex)
      {
          Logger.getLogger(DetailBulletinDAO.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      return true;
     
    }

    @Override
    public boolean update(DetailBulletin obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public DetailBulletin find(int id) {
        
         DetailBulletin db = new DetailBulletin();
      
      try{ 
      ResultSet result = this.connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM detailbulletin WHERE id = " +id);

       if(result.first())
       {
           db = new DetailBulletin(id, result.getString("appreciation"), result.getInt("idBulletin"));
           
           result = this.connect.createStatement().executeQuery(
            "SELECT * FROM detailbulletin " +
            "INNER JOIN evaluation ON detailbulletin.id = evaluation.idDetailBulletin WHERE detailbulletin.id = " +id);
           
           EvaluationDAO evalDao = new EvaluationDAO(this.connect);
           
          
           while(result.next())
           {   
               db.AddEval(evalDao.find(result.getInt("evaluation.id")));  
      
           }
 
           result = this.connect.createStatement().executeQuery(
            "SELECT * FROM detailbulletin " +
            "INNER JOIN enseignement ON enseignement.id = detailbulletin.idEnseignement WHERE detailbulletin.id = " +id);
           
           EnseignementDAO ensDao = new EnseignementDAO(this.connect);
           
           while(result.next())
           {
               db.setEnseignement(ensDao.find(result.getInt("enseignement.id")));
           }
    
           float moy = db.moyenne(db.getEval());
           db.setMoy(moy);
           
       }
     }
      catch (SQLException e) {e.getMessage(); }
      
      return db;
 }
    
    
}

