/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphique;

/**
 *
 * @author domin
 */
public class Graphique {
    public static NewJFrame Frame;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame = new NewJFrame();
        Frame.setVisible(true);
        
        
        // TODO code application logic here
    }
    
}
