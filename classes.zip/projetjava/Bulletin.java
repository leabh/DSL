/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.util.ArrayList;

/**
 *
 * @author Lea
 */
public class Bulletin {

    private int id, id_Trim, id_Ins;
    private String appreciation;
    private ArrayList<DetailBulletin> detailbulletin = new ArrayList<>();
    private float moy;
    
    public Bulletin(){}
    
    public Bulletin(int id, int id_Trim, int id_Ins, String m_appreciation) 
    {
        this.id = id;
        appreciation = m_appreciation;
        this.id_Trim = id_Trim;
        this.id_Ins = id_Ins;
    }
    
    public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
    
     public int getIdTrimestre() 
    {
        return id_Trim;
    }

    public void setIdTrimestre(int id_Trim) 
    {
        this.id_Trim = id_Trim;
    }
    
    
     public int getIdInscription() 
    {
        return id_Ins;
    }

    public void setIdInscription(int id_Ins) 
    {
        this.id_Ins = id_Ins;
    }
    
    
    public String getAppreciation() 
    {
        return appreciation;
    }

    public void setAppreciation(String appreciation) 
    {
        this.appreciation = appreciation;
    }
    
    public ArrayList<DetailBulletin> getDetailBulletin()
    {
        return detailbulletin;
    }
    
    public void setDetailBulletin(ArrayList<DetailBulletin> detailbulletin)
    {
        this.detailbulletin = detailbulletin;
    }
    
      public void AddDetailBulletin(DetailBulletin db)
    {
        if(!detailbulletin.contains(db))
        {
            detailbulletin.add(db);
        } 
    }
      
      public float moyenne(ArrayList<DetailBulletin> db)
    {
        float somme = 0;
        for (int i=0; i<db.size(); i++)
        {  
            somme += db.get(i).getMoy();
        }
        
        moy = (float) somme/db.size();
        return moy;
    }
    
    public float getMoy() 
    {
        return moy;
    }

    public void setMoy(float moy) 
    {
        this.moy = moy;
    }
}
