/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;

import java.util.ArrayList;

/**
 *
 * @author Lea
 */
public class Niveau {

    private int id;
    private String nom;
    private ArrayList<Classe> classes = new ArrayList<>();


    public Niveau(int id, String m_nom) {
      
        this.id = id;
        nom = m_nom;
    }

    public Niveau() {}

     public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
    
     public String getNom() 
    {
        return nom;
    }

    public void setNom(String m_nom) 
    {
        nom = m_nom;
    }
    
    public ArrayList<Classe> getClasse()
    {
        return classes;
    }
    
    public void setClasse(ArrayList<Classe> m_classes)
    {
        classes = m_classes;
    }
    
    public void addClasse(Classe c) {
        
        classes.add(c);
    }
}
