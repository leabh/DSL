/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetjava;
import DAO.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import DAO.*;
import java.util.Scanner;


/**
 *
 * @author Lea
 */
public class ProjetJava {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // TODO code application logic here
        Connexion c = new Connexion("projetjava","root", "");
        
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/projetjava","root", "");
           //Testons
        DAO<Personne> persDao = new PersonneDAO(conn);
        DAO<Bulletin> bulletinDao = new BulletinDAO(conn);
        DAO<Classe> clsDao = new ClasseDAO(conn);
        DAO<DetailBulletin> dbDao = new DetailBulletinDAO(conn);
        
        DetailBulletin b = new DetailBulletin(50, "super", 50, 50);
        dbDao.create(b);
        
       /*Scanner sc = new Scanner(System.in);
       
        System.out.println("Id de la personne que vous recherchez : ");
        int j = sc.nextInt();
        
        //Recherche personne
        Personne p = persDao.find(j); 
        System.out.println("nom : " + p.getNom() + " prénom : " +p.getPrenom());
        
        if("eleve".equals(p.getType()))
        {
            System.out.println(p.getInscription().getId()+ " et " + p.getInscription().getClasse().getNom() +
                    " et " + p.getInscription().getClasse().getNiveau().getNom());
            System.out.println(p.getInscription().getClasse().getAnneeScolaire().getPeriode());
            
        
            System.out.println("Quel trimestre ? : ");
            int i = sc.nextInt();
            System.out.println(p.getInscription().getClasse().getAnneeScolaire().getListeT().get(i).getBulletin().getMoy());
            System.out.println(p.getInscription().getClasse().getAnneeScolaire().getListeT().get(i).getBulletin().getAppreciation());

}*/
    }
}
